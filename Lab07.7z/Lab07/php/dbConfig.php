<?php
    $lokal=1; //1 hodeirako
    if ($lokal)
    {
        $server="localhost";
        $user="id7209609_prlm96";
        $passwd="prlm96";
        $database="id7209609_quiz";
    }
    else
    {
        $server="localhost";
        $user="root";
        $passwd="";
        $database="quiz";
    }
    ?>
